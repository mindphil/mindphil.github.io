"""
OCR and keyword classification for PDF segments.

PDFs are assumed to be pre-oriented (correct rotation before running).

Run standalone to inspect classification results for a single PDF:
    python classifier.py Theisen_Elizabeth/1355_001.pdf
"""

import sys
from pathlib import Path

import fitz
import pytesseract
from PIL import Image
from rapidfuzz import fuzz

from blank_page_detector import detect_segments
from document_types import DOCUMENT_TYPES


OCR_DPI = 300
CONF_AUTO = 0.90
CONF_REVIEW = 0.50

# Chars of OCR text treated as the "title zone" (letterhead + document title).
# A required term found here is a much stronger signal than one buried in
# body boilerplate, which is what caused most cross-type misclassifications.
TITLE_ZONE_CHARS = 300
TITLE_ZONE_SCORE = 0.95


def page_to_image(page: fitz.Page, dpi: int = OCR_DPI) -> Image.Image:
    mat = fitz.Matrix(dpi / 72, dpi / 72)
    pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
    return Image.frombytes("RGB", [pix.width, pix.height], pix.samples)


def ocr_page(page: fitz.Page) -> str:
    return pytesseract.image_to_string(page_to_image(page))


def ocr_segment(doc: fitz.Document, page_indices: list[int]) -> str:
    return "\n".join(ocr_page(doc[i]) for i in page_indices)


def classify_text(text: str) -> tuple[str, float, list[str]]:
    """
    Returns (doc_type_name, confidence_0_to_1, matched_keywords).
    Scores by fraction of keywords matched; requires at least one required term.
    A required term found in the title zone (top of the first page) outranks
    any keyword-density score from another type: document titles are the
    strongest signal, and body boilerplate was causing cross-type wins.
    """
    lower = text.lower()
    head = lower[:TITLE_ZONE_CHARS]
    best_type = None
    best_rank = (False, 0.0)
    best_score = 0.0
    best_hits: list[str] = []

    for doc_type, defn in DOCUMENT_TYPES.items():
        required_ok = any(
            fuzz.partial_ratio(req, lower) >= 88
            for req in defn["required"]
        )
        if not required_ok:
            continue

        hits = [kw for kw in defn["keywords"] if fuzz.partial_ratio(kw, lower) >= 88]
        if len(hits) < defn.get("min_keywords", 1):
            continue

        raw_score = min(len(hits) / max(len(defn["keywords"]) * 0.5, 1), 1.0)
        title_hit = any(fuzz.partial_ratio(req, head) >= 88 for req in defn["required"])
        score = max(raw_score, TITLE_ZONE_SCORE) if title_hit else raw_score
        # Rank on the raw keyword score so that when two types both match in
        # the title zone (fuzzy near-misses happen), keyword evidence decides.
        if (title_hit, raw_score) > best_rank:
            best_rank = (title_hit, raw_score)
            best_score = score
            best_type = doc_type
            best_hits = hits

    if best_type is None:
        return "UNKNOWN", 0.0, []

    return best_type, round(best_score, 2), best_hits


def classify_pdf(pdf_path: str) -> list[dict]:
    """
    Segment → OCR → classify. Returns one result dict per segment.
    """
    doc = fitz.open(pdf_path)
    results = []

    for seg in detect_segments(pdf_path):
        text = ocr_segment(doc, seg["pages"])
        doc_type, confidence, hits = classify_text(text)
        defn = DOCUMENT_TYPES.get(doc_type, {})

        results.append({
            "segment": seg["segment"],
            "page_range": seg["page_range"],
            "page_count": seg["page_count"],
            "pages": seg["pages"],
            "doc_type": doc_type,
            "alora_folder": defn.get("alora_folder", "MISCELLANEOUS DOCUMENTS"),
            "confidence": confidence,
            "matched_keywords": hits,
            "ocr_snippet": text[:300].replace("\n", " "),
        })

    doc.close()
    return results


def main():
    if len(sys.argv) < 2:
        print("Usage: python classifier.py <pdf_file>")
        sys.exit(1)

    results = classify_pdf(sys.argv[1])
    print(f"\nClassification: {Path(sys.argv[1]).name}")
    print("=" * 70)

    for r in results:
        if r["confidence"] >= CONF_AUTO:
            flag = "[AUTO]"
        elif r["confidence"] >= CONF_REVIEW:
            flag = "[REVIEW]"
        else:
            flag = "[MANUAL]"

        print(f"\nSegment {r['segment']}  pages {r['page_range']}  ({r['page_count']}p)  {flag}")
        print(f"  Type      : {r['doc_type']}")
        print(f"  Folder    : {r['alora_folder']}")
        print(f"  Confidence: {r['confidence']:.0%}")
        print(f"  Keywords  : {', '.join(r['matched_keywords']) or 'none'}")
        print(f"  Snippet   : {r['ocr_snippet'][:120]}...")


if __name__ == "__main__":
    main()
