# What This Does

The program opens the stack, reads each page, recognizes what kind of document it's looking at, splits the stack apart, and files each document in the right
folder with the right name; flagging anything it isn't sure about for a human to double-check.

**Everything runs on the local computer. No documents are uploaded anywhere,
no internet connection is needed, and no employee information leaves the
machine.**

---

## How It Works, Step by Step

### 1. Finding the document boundaries

Our scanner scans both sides of every sheet, but the paperwork is printed on
one side only, so every other page in the scan is blank. The program uses
those blank pages as natural dividers: the pages between blanks are treated
as one document.

### 2. Reading the pages

Each page is a picture, not text. The program uses OCR (**optical character
recognition,** the same technology banks use to read checks) to convert the
picture of each page into text it can search.

### 3. Recognizing the document

The program compares the text against a catalog of known RHS documents. Each
document type has a list of telltale phrases: for example, a page containing
"Employment Eligibility Verification" and "USCIS" is an I-9; a page with
"Proof of Residency Form" at the top is exactly that. Phrases found in the
**title area at the top of the page** count the most, since that's how a
person would identify a document too.

### 4. Deciding how confident it is

Every match gets a confidence score, which determines what happens next:

| Confidence    | What happens                                                     |
| ------------- | ---------------------------------------------------------------- |
| 90% or higher | Filed automatically into the correct folder                      |
| 50–89%       | Saved to a`_review` folder, likely right, needs a quick look |
| Below 50%     | Saved to`_review` marked MANUAL, a person decides            |

The program is deliberately cautious: when in doubt, it asks a human instead
of guessing.

### 5. Splitting, naming, filing

Each recognized document is cut out of the big scan, saved as its own PDF,
named to the RHS convention,

```
LastName_FirstName_DocumentType_Date.pdf
e.g.  Theisen_Elizabeth_I-9_07-01-2026.pdf
```

and placed in the folder matching the Alora filing guide
(Application Forms, Inservices, Miscellaneous, or Credentials). From there,
the files are ready to upload into Alora Plus.

### A safety feature: the dry run

The program can be run in "dry run" mode, which prints a full preview of what
it *would* do, without writing a single
file. We review that preview before letting it actually file anything.

---

## Manual Work Still Required

The program handles the tedious middle, but people are still needed at the
start and the end.

**Before running:**

1. **Straighten the pages.** The scanner sometimes captures pages sideways or
   upside down. Pages must be rotated right-side up first (I used the free
   tool **PDFsam**). The program reads pages like a person does, it can't
   read a sideways page reliably.
2. **Separate documents that were fed as one stack.** If several documents go
   through the scanner back-to-back with no gap, there's no blank page
   between them and the program sees them as one document. Those scans need
   a quick manual split in PDFsam first.

**After running:**

3. **Clear the `_review` folder.** Anything the program wasn't confident
   about lands here with its best guess in the filename. A person confirms
   or corrects it, renames if needed, and moves it to the right folder.
   Reviewing a flagged file takes seconds — far faster than processing the
   whole stack by hand.
4. **Upload to Alora Plus.** The program prepares files on disk; uploading
   into Alora is still done by staff.

---

## The Technology (One-Line Descriptions)

| Piece                          | What it is                                                                                                                                                                          |
| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Python**               | The programming language everything is written in, free and widely used                                                                                                           |
| **PyMuPDF**              | Opens, splits, and saves PDF files; also detects blank pages                                                                                                                        |
| **Tesseract**            | The OCR engine that turns page images into readable text (open-source, originally developed at HP/Google)                                                                           |
| **rapidfuzz**            | "Fuzzy" text matching; lets the program recognize a phrase even when the OCR misreads a letter or two                                                                             |
| **The document catalog** | A plain, editable list of RHS document types and their telltale phrases (`document_types.py`). Adding a new form type means adding a few lines here, not reprogramming anything |

All of these are free, open-source tools. There are no license fees and no
subscriptions.

---

## Porting to the RHS Work Computer

### Files to copy

The whole project folder, at minimum these files:

| File                          | Role                                                                                          |
| ----------------------------- | --------------------------------------------------------------------------------------------- |
| `pipeline.py`               | **Main program**  (the one you actually run)                                            |
| `classifier.py`             | OCR + document recognition logic                                                              |
| `blank_page_detector.py`    | Finds the blank-page dividers between documents                                               |
| `document_types.py`         | The document catalog (phrases + destination folders) this is the file you edit to tune recognition |
| `test_classification.py`    | Self-check: verifies the catalog still recognizes the 22 known test pages after any edits     |
| `Document_Filing_Guide.pdf` | Reference: the Alora filing guide                                                             |
| `PROJECT_NOTES.md`          | Technical project log                                                                         |

### Python environment

The program needs Python plus four packages: `pymupdf`, `pytesseract`,
`rapidfuzz`, and `pillow`; and the Tesseract OCR engine itself.

The easiest path is **Miniconda**, because the `conda-forge` version of
Tesseract bundles the OCR engine (no separate system install, no admin
rights needed beyond installing Miniconda):

```
conda create -n rhs python=3.11
conda activate rhs
conda install -c conda-forge pymupdf pytesseract rapidfuzz pillow tesseract
```

Or, to reproduce the existing environment exactly: on work computer run
`conda env create -f environment.yml`

### Folder setup per employee

Create one folder per employee, named `LastName_FirstName` (the program reads
the employee's name from the folder name), and place the raw scanner PDFs
directly inside it:

```
Theisen_Elizabeth/
  1355_001.pdf            ← raw scans from the copier, pre-oriented
  1357_001.pdf
  1358_001.pdf
  Application_Forms/      ← output folders
  INSERVICES/
  MISCELLANEOUS/
  Credentials/
  _review/                ← created automatically for flagged items
```

### Running it

```
conda activate rhs

# Preview only:
python pipeline.py Theisen_Elizabeth/ --dry-run

# Real run:
python pipeline.py Theisen_Elizabeth/
```

Always dry-run first, skim the preview, then run for real.

### After editing the document catalog

Any time `document_types.py` is tuned (new form type, new phrases), run the
self-check to make sure nothing that used to work broke:

```
python test_classification.py
```

It should end with `0 misclassified`.
