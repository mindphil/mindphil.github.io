"""
Document type definitions for keyword-based classification.

Each entry:
  alora_folder   : top-level Alora tab where the file is saved
  alora_subfolder: subfolder within the tab (empty string if none)
  keywords       : strings that strongly suggest this document type (case-insensitive)
  required       : at least ONE of these must appear for a match to count
  min_keywords   : minimum total keyword hits required (default 1)

Edit this file to add new document types or tune keywords.
"""

DOCUMENT_TYPES: dict[str, dict] = {

    # ── APPLICATION FORMS ──────────────────────────────────────────────────────

    "I-9": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "employment eligibility verification",
            "form i-9",
            "uscis",
            "list of acceptable documents",
            "section 1",
            "preparer and/or translator",
        ],
        "required": ["form i-9", "employment eligibility verification"],
        "min_keywords": 2,
    },

    "W-4": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "employee's withholding certificate",
            "form w-4",
            "internal revenue service",
            "withholding",
            "allowances",
            "filing status",
            "step 2",
            "multiple jobs",
        ],
        "required": ["w-4"],
        "min_keywords": 2,
    },

    "Employment Application": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "employment application",
            "application for employment",
            "position applied for",
            "work history",
            "previous employer",
            "references",
            "education",
            "social security",
        ],
        "required": ["employment application", "application for employment"],
        "min_keywords": 2,
    },

    # RHS uses a form titled '"CONFIDENTIAL" REFERENCE INQUIRY FORM'.
    "Reference Check Form": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "reference check",
            "reference form",
            "reference inquiry",
            "previous employer",
            "rehire",
            "reason for leaving",
            "would you rehire",
        ],
        "required": ["reference check", "reference form", "reference inquiry"],
        "min_keywords": 2,
    },

    "Background Check Authorization": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "background check",
            "background investigation",
            "authorization",
            "consumer report",
            "fair credit reporting",
            "fcra",
        ],
        "required": ["background check", "background investigation"],
        "min_keywords": 2,
    },

    # RHS letter says "extend the following employment offer" — no "offer of
    # employment" / "offer letter" phrasing anywhere in the body.
    "Offer Letter": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "offer of employment",
            "offer letter",
            "we are pleased to offer",
            "employment offer",
            "start date",
            "compensation",
            "contingent upon",
        ],
        "required": [
            "offer of employment",
            "offer letter",
            "we are pleased to offer",
            "employment offer",
        ],
        "min_keywords": 1,
    },

    # Requires the exact title to win over HIPAA Privacy Notice, which also
    # mentions confidentiality but is a different form entirely.
    "Confidentiality Agreement": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "confidentiality agreement",
            "non-disclosure",
            "confidential information",
            "strictest confidence",
            "proprietary",
            "not disclose",
            "agree to keep confidential",
        ],
        "required": ["confidentiality agreement"],
        "min_keywords": 2,
    },

    # Kept narrow on purpose: generic phrases like "i acknowledge" appear on
    # nearly every RHS form and made this type a catch-all that outscored
    # Orientation List, Field Manual Ack, and Code of Ethics pages.
    "Policy Acknowledgement": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "i have read",
            "policy acknowledgement",
            "acknowledgement of receipt",
            "code of conduct",
            "employee handbook",
            "policies and procedures",
            "i understand and agree",
        ],
        "required": [
            "policy acknowledgement",
            "acknowledgement of receipt",
            "policies and procedures",
        ],
        "min_keywords": 2,
    },

    # PASSPO "Assisted Living and Individual Provider Code of Ethics" —
    # dense full-page text, previously swallowed by Policy Acknowledgement.
    "Code of Ethics": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "code of ethics",
            "passpo",
            "requirements for providers",
            "agency providers",
            "case manager",
        ],
        "required": ["code of ethics", "passpo"],
        "min_keywords": 2,
    },

    # "FIELD MANUAL EMPLOYEE ACKNOWLEDGEMENT FORM" (1358 p30).
    "Field Manual Acknowledgement": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "field manual",
            "employee acknowledgement form",
            "field handbook",
            "not a contract of employment",
        ],
        "required": ["field manual"],
        "min_keywords": 2,
    },

    # Application-time questionnaire: "Employee Questionnaire" (1358 p28).
    "Employee Questionnaire": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "employee questionnaire",
            "nursing assistant",
            "training course",
            "means of transportation",
            "valid driver's license",
        ],
        "required": ["employee questionnaire"],
        "min_keywords": 2,
    },

    "Disclosure Statement": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "disclosure statement",
            "i hereby disclose",
            "conflict of interest",
            "financial interest",
        ],
        "required": ["disclosure statement", "i hereby disclose"],
        "min_keywords": 1,
    },

    "Annual Abuse Registry": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "abuse registry",
            "annual abuse",
            "abuse neglect",
            "registry check",
            "adult protective",
        ],
        "required": ["abuse registry", "annual abuse"],
        "min_keywords": 1,
    },

    "Paychex Employee Info": {
        "alora_folder": "APPLICATION FORMS",
        "alora_subfolder": "",
        "keywords": [
            "paychex",
            "employee information",
            "direct deposit",
            "payroll",
            "tax withholding",
        ],
        "required": ["paychex"],
        "min_keywords": 1,
    },

    # ── INSERVICES ─────────────────────────────────────────────────────────────

    # "home health aide" must NOT be a required term here — it appears on the
    # offer letter, job description, and half the other RHS forms, and was
    # pulling them all into this type. RHS titles this form
    # "Skilled Validation Summary".
    "HHA Competency Evaluation": {
        "alora_folder": "INSERVICES",
        "alora_subfolder": "",
        "keywords": [
            "hha competency",
            "skilled validation summary",
            "competency evaluation",
            "skills checklist",
            "aide competency",
            "return demonstration",
        ],
        "required": ["hha competency", "competency evaluation", "skilled validation"],
        "min_keywords": 1,
    },

    "HHA Test": {
        "alora_folder": "INSERVICES",
        "alora_subfolder": "",
        "keywords": [
            "hha test"
            "health aide test",
            "home health aide test",
            "aide examination",
            "multiple choice",
            "true or false",
            "which of the following"
            "primary symptom for a urinary tract infection"
            "all of the above",
        ],
        "required": ["health aide test", "hha test", "home health aide test", "aide examination"],
        "min_keywords": 1,
    },

    # Requires "notice of privacy practices" or "privacy notice" — not just
    # "hipaa" alone — so it doesn't fire on Confidentiality Agreements that
    # happen to mention HIPAA in passing.
    "HIPAA Privacy Notice": {
        "alora_folder": "INSERVICES",
        "alora_subfolder": "",
        "keywords": [
            "notice of privacy practices",
            "notice of privacy rights",
            "privacy notice",
            "hipaa",
            "protected health information",
            "privacy of protected health information",
            "your health information",
        ],
        "required": [
            "notice of privacy practices",
            "notice of privacy rights",
            "privacy notice",
            # Catches untitled continuation pages of the notice; titled pages
            # of other doc types (e.g. Confidentiality Agreement) still win
            # via the classifier's title-zone ranking.
            "protected health information",
        ],
        "min_keywords": 2,
    },

    "Orientation": {
        "alora_folder": "INSERVICES",
        "alora_subfolder": "",
        "keywords": [
            "orientation",
            "orientation checklist",
            "orientation list",
            "new employee orientation",
            "orientation manual",
            "personnel orientation",
        ],
        "required": ["orientation"],
        "min_keywords": 2,
    },

    # ── MISCELLANEOUS DOCUMENTS ────────────────────────────────────────────────

    "Proof of Residency": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "proof of residency",
            "proof of address",
            "utility bill",
            "bank statement",
            "residency",
        ],
        "required": ["proof of residency", "proof of address"],
        "min_keywords": 1,
    },

    "WOTC Screening": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "wotc",
            "work opportunity",
            "hiretech",
            "tax credit",
            "targeted group",
            "irs form 8850",
        ],
        "required": ["wotc", "work opportunity", "hiretech"],
        "min_keywords": 1,
    },

    "Employee File Checklist": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "employee file checklist",
            "file checklist",
            "checklist",
            "documents required",
            "new hire checklist",
        ],
        "required": ["employee file checklist", "file checklist", "new hire checklist"],
        "min_keywords": 1,
    },

    # min_keywords 1: the continued/signature page only says "job description"
    # once and was losing to HHA Competency via "home health aide".
    "Job Description": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "job description",
            "position description",
            "duties and responsibilities",
            "essential functions",
            "physical/environment demands",
            "qualifications",
            "reports to",
        ],
        "required": ["job description", "position description"],
        "min_keywords": 1,
    },

    # "plunging necklines" / "camisole" catch the untitled signature page of
    # the RHS dress code, which scans as its own segment.
    "Dress Code Policy": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "dress code",
            "attire",
            "appearance policy",
            "uniform",
            "professional appearance",
            "plunging necklines",
            "camisole",
        ],
        "required": ["dress code", "attire", "appearance policy", "plunging necklines", "camisole"],
        "min_keywords": 1,
    },

    "Paperwork Policy": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "paperwork policy",
            "terminated employees",
            "rectify all of my medical records",
            "evv",
            "electronic visit verification",
        ],
        "required": ["paperwork policy", "terminated employees", "evv", "electronic visit verification"],
        "min_keywords": 1,
    },

    # RHS "Documentation Policy" (timesheets / visit notes) — distinct form
    # from the Paperwork Policy; previously classified UNKNOWN.
    "Documentation Policy": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "documentation policy",
            "timesheets",
            "visit notes",
            "completed electronically",
            "scheduled visit",
        ],
        "required": ["documentation policy"],
        "min_keywords": 2,
    },

    # Title on the RHS form: "DRIVER'S LICENSE AUTOMOBILE INSURANCE AGREEMENT".
    "Auto Insurance Agreement": {
        "alora_folder": "MISCELLANEOUS DOCUMENTS",
        "alora_subfolder": "",
        "keywords": [
            "auto insurance",
            "automobile insurance",
            "insurance agreement",
            "liability insurance",
            "driver's license",
            "personal vehicle",
            "proof of insurance",
        ],
        "required": [
            "auto insurance",
            "automobile insurance",
            "insurance agreement",
            "driver's license",
        ],
        "min_keywords": 1,
    },

    # ── CREDENTIALS TAB ────────────────────────────────────────────────────────

    # Bare "cna" must not be a required term: fuzzy matching hits the "STNA"
    # in the RHS letterhead on every page.
    "CNA License": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "certified nursing assistant",
            "cna license",
            "cna certificate",
            "nurse aide registry",
            "state registry",
        ],
        "required": ["certified nursing assistant", "nurse aide registry", "cna license", "cna certificate"],
        "min_keywords": 1,
    },

    "Background Check Clearance": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "background check",
            "consent and attestation form",
            "criminal record check",
            "senate bill 160",
            "s.b. 160",
        ],
        "required": ["background check", "consent and attestation form", "criminal record check", "senate bill 160"],
        "min_keywords": 1,
    },

    # "aide certification" was matching "...Home Health Aide training program
    # and certification" on the Job Description; require explicit license/
    # certificate phrasing instead.
    "HHA License": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "hha certification",
            "hha license",
            "home health aide certificate",
            "expiration date",
        ],
        "required": ["hha certification", "hha license", "home health aide certificate"],
        "min_keywords": 1,
    },

    "CPR Certification": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "cpr",
            "cardiopulmonary resuscitation",
            "first aid",
            "basic life support",
            "bls",
            "aed",
        ],
        "required": ["cpr", "cardiopulmonary resuscitation", "basic life support", "bls"],
        "min_keywords": 1,
    },

    "TB Test": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "tuberculosis",
            "tb test",
            "ppd",
            "mantoux",
            "chest x-ray",
            "tb screening",
        ],
        "required": ["tuberculosis", "tb test", "ppd", "mantoux"],
        "min_keywords": 1,
    },

    "Training Certificate": {
        "alora_folder": "CREDENTIALS TAB",
        "alora_subfolder": "",
        "keywords": [
            "certificate of completion",
            "certificate of training",
            "this certifies",
            "has successfully completed",
            "continuing education",
            "in-service training",
        ],
        "required": [
            "certificate of completion",
            "certificate of training",
            "has successfully completed",
        ],
        "min_keywords": 1,
    },
}
