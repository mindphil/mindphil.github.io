"""
Main pipeline: process all PDFs in an employee folder and file split segments.

Folder name must be LastName_FirstName (e.g. Theisen_Elizabeth).
Output filename format: LastName_FirstName_DocumentType_MM-DD-YYYY.pdf

Segments at or above CONF_AUTO go to the appropriate subfolder.
Segments below CONF_AUTO go to _review/ with their confidence in the name
so they can be manually renamed and moved.

Usage:
    python pipeline.py Theisen_Elizabeth/
    python pipeline.py Theisen_Elizabeth/ --dry-run
"""

import sys
from datetime import date
from pathlib import Path

import fitz

from classifier import classify_pdf, CONF_AUTO, CONF_REVIEW

TODAY = date.today().strftime("%m-%d-%Y")

FOLDER_MAP = {
    "APPLICATION FORMS":      "Application_Forms",
    "INSERVICES":             "INSERVICES",
    "MISCELLANEOUS DOCUMENTS": "MISCELLANEOUS",
    "CREDENTIALS TAB":        "Credentials",
    "ANNUAL EVAL":            "MISCELLANEOUS",
}


def parse_name(folder_name: str) -> tuple[str, str]:
    """'Theisen_Elizabeth' → ('Theisen', 'Elizabeth')"""
    parts = folder_name.split("_", 1)
    return (parts[0], parts[1]) if len(parts) == 2 else (parts[0], "")


def safe_type_name(doc_type: str) -> str:
    return doc_type.replace(" ", "_").replace("/", "-")


def extract_pages(src_path: Path, page_indices: list[int], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    src = fitz.open(str(src_path))
    dst = fitz.open()
    for i in page_indices:
        dst.insert_pdf(src, from_page=i, to_page=i)
    dst.save(str(out_path))
    src.close()
    dst.close()


def process_folder(folder: Path, dry_run: bool = False) -> None:
    last, first = parse_name(folder.name)
    name_prefix = f"{last}_{first}"

    pdfs = sorted(p for p in folder.glob("*.pdf") if not p.name.startswith("_"))
    if not pdfs:
        print(f"No PDFs found in {folder}")
        return

    print(f"\nEmployee: {last}, {first}")
    print(f"Date tag: {TODAY}")
    print(f"PDFs to process: {[p.name for p in pdfs]}\n")

    # Track how many times each doc type appears so duplicates get a suffix
    type_counts: dict[str, int] = {}

    for pdf_path in pdfs:
        print(f"── {pdf_path.name} ──")
        results = classify_pdf(str(pdf_path))

        for r in results:
            doc_type = r["doc_type"]
            confidence = r["confidence"]

            type_counts[doc_type] = type_counts.get(doc_type, 0) + 1
            count = type_counts[doc_type]
            dup_suffix = f"_{count}" if count > 1 else ""

            type_slug = safe_type_name(doc_type)
            filename = f"{name_prefix}_{type_slug}{dup_suffix}_{TODAY}.pdf"

            if confidence >= CONF_AUTO:
                subfolder = FOLDER_MAP.get(r["alora_folder"], "MISCELLANEOUS")
                out_path = folder / subfolder / filename
                status = f"[AUTO  {confidence:.0%}]"
            else:
                review_prefix = "REVIEW" if confidence >= CONF_REVIEW else "MANUAL"
                out_path = folder / "_review" / f"{review_prefix}_{confidence:.0%}_{filename}"
                status = f"[{review_prefix} {confidence:.0%}]"

            rel = out_path.relative_to(folder)
            print(f"  Seg {r['segment']}  {status}  {r['page_range']}p  →  {rel}")

            if not dry_run:
                extract_pages(pdf_path, r["pages"], out_path)

    if dry_run:
        print("\n[dry-run] No files written.")
    else:
        print("\nDone.")


def main():
    if len(sys.argv) < 2:
        print("Usage: python pipeline.py <employee_folder> [--dry-run]")
        sys.exit(1)

    folder = Path(sys.argv[1])
    if not folder.is_dir():
        print(f"Not a directory: {folder}")
        sys.exit(1)

    dry_run = "--dry-run" in sys.argv
    process_folder(folder, dry_run=dry_run)


if __name__ == "__main__":
    main()
