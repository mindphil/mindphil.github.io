"""
Step 1: Blank page detection and document segmentation.

Renders each page to a grayscale image and measures the fraction of
white pixels. Pages above the WHITE_THRESHOLD are considered blank
(duplex-scan artifacts). Contiguous non-blank pages form a candidate
document segment.

Run:
    python blank_page_detector.py testcases/1355_001.pdf
    python blank_page_detector.py testcases/1357_001.pdf
    python blank_page_detector.py testcases/1358_001.pdf
"""

import sys
from pathlib import Path
import fitz  # PyMuPDF


WHITE_THRESHOLD = 0.95   # fraction of white pixels → blank page
DPI = 72                  # low-res is fine for blank detection (fast)


def is_blank(page: fitz.Page, threshold: float = WHITE_THRESHOLD) -> bool:
    mat = fitz.Matrix(DPI / 72, DPI / 72)
    pix = page.get_pixmap(matrix=mat, colorspace=fitz.csGRAY)
    # samples is a bytes object: one byte per pixel (0=black, 255=white)
    samples = pix.samples
    white_pixels = sum(1 for b in samples if b >= 250)
    return white_pixels / len(samples) >= threshold


def detect_segments(pdf_path: str) -> list[dict]:
    """
    Returns a list of segments, each a dict:
        { "pages": [0-indexed page numbers], "page_range": "1–N" (1-indexed) }
    """
    doc = fitz.open(pdf_path)
    segments = []
    current = []

    for i, page in enumerate(doc):
        if is_blank(page):
            if current:
                segments.append(current)
                current = []
        else:
            current.append(i)

    if current:
        segments.append(current)

    doc.close()

    return [
        {
            "segment": idx + 1,
            "pages": pages,
            "page_range": f"{pages[0]+1}–{pages[-1]+1}",
            "page_count": len(pages),
        }
        for idx, pages in enumerate(segments)
    ]


def main():
    if len(sys.argv) < 2:
        print("Usage: python blank_page_detector.py <pdf_file>")
        sys.exit(1)

    pdf_path = Path(sys.argv[1])
    if not pdf_path.exists():
        print(f"File not found: {pdf_path}")
        sys.exit(1)

    print(f"\nFile: {pdf_path.name}")
    print("-" * 50)

    segments = detect_segments(str(pdf_path))

    print(f"Found {len(segments)} document segment(s):\n")
    for seg in segments:
        print(f"  Segment {seg['segment']:>2}  |  pages {seg['page_range']:>8}  |  {seg['page_count']} page(s)")

    print(f"\nTotal segments: {len(segments)}")


if __name__ == "__main__":
    main()
