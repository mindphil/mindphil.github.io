"""Regression check for classify_text against vision-transcribed page text.

Each sample approximates the OCR text of a real Theisen test-case page
(letterhead included, since it lands in the title zone).
"""
import sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent))
from classifier import classify_text, CONF_AUTO, CONF_REVIEW

LETTERHEAD = "Richard Health Systems The Home HealthCare Agency & STNA Training Center "

SAMPLES = {
    # (file, page, expected_type)
    ("1357", 4, "Code of Ethics"): (
        "PASSPO Assisted Living and Individual Provider Code of Ethics "
        "Requirements for providers to become, and to remain, certified "
        "PASSPO All Providers 173-39-02 (B)(8)(a) through (n), and Agency providers (C)(1)(d) "
        "Ethical, professional, respectful, and legal service standards. The provider shall not engage in any unethical, "
        "unprofessional, disrespectful, or illegal behavior including the following: Consuming alcohol while providing services "
        "watching television, movies, videos, or playing games on computers, personal phones, or other electronic devices "
        "case manager reviewer respectfully. Worker printed name Worker signature Date"
    ),
    ("1357", 8, "Proof of Residency"): (
        "Proof of Residency Form Applicant Name Elizabeth Theisen please print "
        "By marking this box, I affirm that I have lived in the State of Ohio continuously for the last five years. "
        "Listed below is my current address and a list of my prior residences for the last five years. "
        "I attest that the information that I have documented is correct. Signature Date "
        "Current Residence: Street City County State Zip Code Date of Residence Previous Residence"
    ),
    ("1357", 12, "Documentation Policy"): (
        LETTERHEAD +
        "Documentation Policy I agree to adhere to the procedure in which all services provided by Richard Health Systems "
        "are documented. Timesheets are due in the office every Monday. All visit notes are to be completed electronically "
        "on the day the visit is scheduled. The location should be turned on, on the device being used to complete visit notes. "
        "Any issues with logging in, rescheduling or not accessing the client must be reported to the agency on the day/time "
        "of the scheduled visit. I understand that not following the previously mentioned policy may cause a delay/deduction "
        "in total paid hours. Employee Date Employer Date"
    ),
    ("1357", 14, "Offer Letter"): (
        LETTERHEAD +
        "Dear Elizabeth, With great pleasure, I would like to extend the following employment offer. "
        "Position: Home Health Aide Name: Elizabeth Theisen Start date: 10/18/2024 Salary: Varies per case "
        "This employment offer is contingent upon the successful completion of background check, drug screening, "
        "reference check, I-9 form, etc. This offer is not a contract of employment, and either party may terminate "
        "employment at any time, with or without cause. Sincerely, Richard Health Systems"
    ),
    ("1357", 10, "Confidentiality Agreement"): (
        LETTERHEAD +
        "CONFIDENTIALITY AGREEMENT In accordance to the current HIPAA rules and regulations, Richard Health Systems "
        "has a legal and ethical responsibility to safeguard the privacy of all residents/clients and to protect the "
        "confidential medical financial and persona information even though I may not be directly involved in providing "
        "resident/client services. I understand, that such information must be maintained in the strictest confidence. "
        "As a condition of my employment or assignment, I hereby agree that, unless directed by the supervisor, I will not "
        "at any time during or after my employment/assignment with Richard Health System discloses any protected health "
        "information to any person whatsoever. Signature of Employee/Student/Volunteer Date "
        "PASSPORT Employee Code of Ethics Requirements for Every Agency Provider 173-39-02"
    ),
    ("1358", 4, "Employee File Checklist"): (
        "Agency name: Employee File Checklist Copies of certificates and documents must be included with the items "
        "on this checklist Employee Name: Elizabeth Theisen Application Date: 10-18-24 Hire Date: Actual Start Date: "
        "Background Investigations for Employment checks done before hire date and every 5 years, please refer to rule "
        "5123:2-02 for further guidance. Inspector General's Exclusion List Date Completed Sex Offender and Child Victim "
        "Offenders Database Abuser Registry Nurse Aide Registry BCII/FBI Check Rapback"
    ),
    ("1358", 6, "Orientation"): (
        LETTERHEAD +
        "ORIENTATION LIST Welcome and Introduction Company's Philosophy and Mission a) Policies and Procedures "
        "b) Employees Code of Ethics Driver's License Auto Insurance Verification of Valid License or Certification "
        "Verification of BCI/FBI and 6 web site Annual TB testing Verification of CPR card W4 I-9 Employment Eligibility "
        "Verification Verification of Signed Confidentiality Statement Passport Code of Ethics Home safety issues including "
        "bathroom, fire, environmental and electrical safety Skill and Written test Verification of completed Handbook and "
        "Post Test Verification of completed OSHA/Infection Control Module and Post Test I hereby acknowledge that I have "
        "received he Personnel Orientation Information. Employee Date Employer Date"
    ),
    ("1358", 8, "HHA Competency Evaluation"): (
        LETTERHEAD +
        "Skilled Validation Summary For: Elizabeth Theisen Home Health Aide's Name "
        "The home health aide may make home visits independently if she or he has successfully demonstrated required "
        "skills to safely provide care to the patient assigned. Evaluation of skills will be ongoing and must be completed "
        "successfully before independent care assignments. Required Skills Date RN Initials Pulse/Respiration Applying "
        "Elastic Stockings Hand washing Feeding Client Bag Technique Oral Hygiene Denture Care Nurse Signature Date HR Signature Date"
    ),
    ("1358", 10, "HIPAA Privacy Notice"): (
        LETTERHEAD +
        "6. The individual has the right to receive confidential communications of protected health information, the right "
        "to inspect and copy protected health information, the right to amend protected health information, the right to "
        "receive an accounting of disclosures of protected health information and the right to obtain a paper copy of this "
        "Notice from the organization upon request. 7. The organization is required by law to maintain the privacy of "
        "protected health information and to provide individuals with notice of its legal duties and privacy practices "
        "with respect to protected health information. 13. My signature below is an acknowledgement that I have received "
        "a copy of this notice. Employee Signature Date"
    ),
    ("1358", 12, "HIPAA Privacy Notice"): (
        LETTERHEAD +
        "NOTICE OF PRIVACY RIGHTS Name of Organization: RICHARD HEALTH SYSTEMS THIS NOTICE DESCRIBES HOW MEDICAL "
        "INFORMATION ABOUT YOU MAY BE USED AND DISCLOSED AND HOW YOU CAN GET ACCESS TO THIS INFORMATION. PLEASE REVIEW IT "
        "CAREFULLY. 1. Below is a description, including at least one example, of the types of uses and disclosures that "
        "the above organization is permitted to make for each of the following purposes: treatment, payment and health "
        "care operations. Disclosures to other health care providers, including, for example, to patients' attending physicians. "
        "2. Below is a description of each of the other purposes for which the organization is permitted or required "
        "to use or disclose protected health information without an individual's written consent or authorization."
    ),
    ("1358", 14, "Disclosure Statement"): (
        LETTERHEAD +
        "DISCLOSURE STATEMENT Definition: A conflict of interest may occur when Richard Health Systems officers, directors, "
        "or management of staff enters into a relationship with another organization or persons(s) which in its content or "
        "process may result in a compromise of the agencies obligation to act in the best interest of our clients. "
        "I have read and understand the agency's disclosure policy related to avoiding conflict of interest. "
        "I agree to disclose any potential relationship and/or employment with other agencies. Employee Signature Date"
    ),
    ("1358", 16, "Auto Insurance Agreement"): (
        LETTERHEAD +
        "DRIVER'S LICENSE AUTOMOBILE INSURANCE AGREEMENT I, Elizabeth Theisen, while in the employment of Richard Health "
        "Systems agree to have a valid driver's license and adequate automobile insurance for liability, collision, bodily "
        "injury and property damage. I agree to notify Richard Health Systems immediately in writing of any "
        "restrictions/suspensions/non-renewal of my driver's license or any insurance coverage. Employee Signature Date"
    ),
    ("1358", 18, "Paperwork Policy"): (
        LETTERHEAD +
        "PAPERWORK POLICY (TERMINATED EMPLOYEES) I understand that upon my termination from Richard Health Systems, "
        "whether voluntary or involuntary, I agree to rectify all of my medical records. In addition, I will ensure that "
        "all of my medical records (active and discharged charts) are completed and in compliance with Medicare and agency "
        "guidelines. My signature verifies that I agree to adhere to this policy. Signature/Title Date"
    ),
    ("1358", 20, "Dress Code Policy"): (
        LETTERHEAD +
        "Skimpy, Strappy Camisole Tops. Yes, you can wear these barely-there pieces with the help of a blouse, sweater or "
        "jacket worn over them. See Plunging Necklines. Shirts or T-shirts with profanity or any anti-establishment slogans, "
        "any racial slogans Employee Signature: Date Employer Signature: Date"
    ),
    ("1358", 22, "Dress Code Policy"): (
        LETTERHEAD +
        "Employee Dress Code Skin: everyone has it. And one glance at TV, movies and magazines reveals how much people love "
        "to flash it. Plunging Necklines. Some of the lawyers on TV can't seem to get through a case without them. "
        "Low-Rise Pants. Mini and Micro-Mini Skirts. Belly Shirts. See-Through Shirts. Shorts. Open-Back Tops and Dresses. "
        "Flip-flops. These are appropriate for vacations and lounging, not daily office tasks."
    ),
    ("1358", 24, "Job Description"): (
        LETTERHEAD +
        "JOB DESCRIPTION: HOME HEALTH AIDE- continued. 6. Timely responsiveness to all agency customers with excellent "
        "service behaviors. 7. Obtains and documents patient care information. Physical/Environment Demands 1. Must be able "
        "to hear, see, speak, sit, stand, bend and climb stairs, stoop, and lift 50-75 lbs. I have read and understand the "
        "above job description of the Home Health Aide. Employee Signature Date Employer Signature Date"
    ),
    ("1358", 26, "Job Description"): (
        LETTERHEAD +
        "JOB DESCRIPTION: HOME HEALTH AIDE Status: Non-Exempt Supervised by: Registered Nurse, License Practical Nurse "
        "Professional and Personal Qualifications: Successful completion of Home Health Aide training program and "
        "certification. High school diploma or GED equivalent. Primary Duties/Responsibilities: 1. Provide safe personal "
        "care to patients in their home. Bathing, shampoos, skin and foot care, mouth care and perineal care."
    ),
    ("1358", 28, "Employee Questionnaire"): (
        LETTERHEAD +
        "Employee Questionnaire 1. Are you a state tested nursing assistant / HHA/Certified Nursing Assistant YES/NO "
        "2. Are you willing to take 2week CAN training course? NO 3. Do you have 2 years work experience taking care of "
        "individuals in Nursing home, Home Care Ect.? no 5. Do you have a valid driver's license yes 6. Do you have your "
        "own vehicle? YES NO If NO what is your means of transportation? Print Name: Elizabeth Theisen Signature: DATE:"
    ),
    ("1358", 30, "Field Manual Acknowledgement"): (
        LETTERHEAD +
        "FIELD MANUAL EMPLOYEE ACKNOWLEDGEMENT FORM The employee Field Manual describes important information about "
        "Richard Health System subject to change; I acknowledge that revisions to the Field Manual may occur. "
        "I acknowledge that this Field Manual is not a contract of employment. I have received the Field Manual and I "
        "understand that it is my responsibility to read and comply with the policies contained in this Field Handbook "
        "and any revisions made to it. Employee Signature Date Employer Signature Date"
    ),
    ("1358", 34, "HHA Test"): (
        "RICHARD HEALTH SYSTEMS HOME HEALTH AIDE TEST 46) When transferring a client from a bed to a wheel chair, "
        "best practices include: a) Record the move in case the client falls b) Assist the client into a sitting position "
        "47) A client is receiving oxygen through a nasal tube. 48) Proper hand washing procedures include: "
        "49) In case of an emergency, the most important number to call is: 50) You arrive at a client's home that lives alone. "
        "What do you do first? a) Call the emergency medical service"
    ),
    ("1355", 4, "Reference Check Form"): (
        "RICHARD HEALTH SYSTEMS 5237 RENWYCK DRIVE TOLEDO OH 43615 \"CONFIDENTIAL\" REFERENCE INQUIRY FORM "
        "Applicant: please complete the following: To Whom It May Concern: I have applied for employment at Richard Health "
        "Systems. I authorize you to release all information requested below by Richard Health Systems, including "
        "information concerning my character, habits, abilities, and reasons for leaving your company. Name of Company "
        "Position Employee Name Start Date End Date Reason For Leaving Applicant's Signature Date "
        "Job Performance Attendance Quality of Work Ability to Work with Others Rehirable Excellent Good Standard Fair Poor"
    ),
    ("1357", 6, "Policy Acknowledgement"): (
        LETTERHEAD +
        "POLICES AND PROCEDURES Name: Elizabeth Theisen Title: Home Health Caregiver Aide I have received a copy of "
        "Richard Health Systems Policies and Procedures and discussed the contents with an RHS representative. I agree to "
        "abide by the Policies and Procedures as well as the following: 1. I have read and received a copy of my job "
        "description and expectations of Home Healthcare as a DON, HR, Clerical and Field Staff. 4. I have read and signed "
        "the Passport Code of Ethics. I HAVE READ AND UNDERSTAND THE ABOVE POLICES AND PROCEDURES. Employee Signature Date"
    ),
}

auto = review = manual = wrong = 0
for (f, p, expected), text in SAMPLES.items():
    dtype, conf, hits = classify_text(text)
    band = "AUTO" if conf >= CONF_AUTO else "REVIEW" if conf >= CONF_REVIEW else "MANUAL"
    ok = dtype == expected
    if not ok:
        wrong += 1
    if band == "AUTO":
        auto += 1
    elif band == "REVIEW":
        review += 1
    else:
        manual += 1
    mark = "ok " if ok else "WRONG"
    print(f"{mark} {f} p{p:<3} {band:<7} {conf:>4.0%}  got={dtype:<30} want={expected}")

print(f"\n{len(SAMPLES)} pages: {auto} auto, {review} review, {manual} manual, {wrong} misclassified")
